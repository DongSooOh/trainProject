package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class CrxControllerImpl {

	// 메인 페이지
    @GetMapping("/main.do")
    public String main() {
        return "main"; 
    }
    
    /********** 공지사항 **********/
    
    // 공지사항 목록
    @GetMapping("/noticeList.do")
    public String noticeList() {
        return "noticeList"; 
    }
    
    // 공지사항 작성
    @GetMapping("/noticeAdd.do")
    public String noticeAdd() {
        return "noticeAdd"; 
    }
    
    // 공지사항 상세보기
    @GetMapping("/noticeDetail.do")
    public String noticeDetail() {
        return "noticeDetail"; 
    }
    
    // 공지사항 수정
    @GetMapping("/noticeMod.do")
    public String noticeMod() {
        return "noticeMod"; 
    }
    
    @GetMapping("/noticeUpdate.do")
    public String noticeUpdate() {
        return "noticeUpdate"; 
    }
    
    // 공지사항 삭제
    @GetMapping("/noticeDelete.do")
    public String noticeDelete() {
        return "noticeList"; 
    }
    
    /********** FAQ **********/
    
    // FAQ 목록
    @GetMapping("/faqList.do")
    public String faqList() {
        return "/faqList"; 
    }
    
    // FAQ 작성
    @GetMapping("/faqAdd.do")
    public String faqAdd() {
        return "/faqAdd"; 
    }
    
    // FAQ 상세보기
    @GetMapping("/faqDetail.do")
    public String faqDetail() {
        return "/faqDetail";
    }
    
    // FAQ 수정
    @GetMapping("/faqMod.do")
    public String faqMod() {
        return "/faqMod"; 
    }
    
    @GetMapping("/faqUpdate.do")
    public String faqUpdate() {
        return "faqUpdate"; 
    }
    
    // FAQ 삭제
    @GetMapping("/faqDelete.do")
    public String faqDelete() {
        return "/faqList"; 
    }
    
    /********** 고객센터 **********/
    
    // 공지사항
    @GetMapping("/customerservice.do")
    public String customerservice() {
        return "customerservice"; 
    }
    
    /********** 유실물 안내 **********/
    
    // 유실물 목록
    @GetMapping("/lostItemList.do")
    public String lostItemList() {
        return "/lostItemList"; 
    }
    
    // 유실물 작성
    @GetMapping("/lostItemAdd.do")
    public String lostItemAdd() {
        return "/lostItemAdd"; 
    }
    
    // 유실물 상세보기
    @GetMapping("/lostItemDetail.do")
    public String lostItemDetail() {
        return "/lostItemDetail";
    }
    
    /********** 안내사항 **********/
    
    // 안내사항
    @GetMapping("/guideline.do")
    public String guideline() {
        return "guideline"; 
    }
    
    /********** 1:1문의 **********/
    
    // Q&A 목록
    @GetMapping("/qnaList.do")
    public String qnaList() {
        return "qnaList"; 
    }
    
    // Q&A 작성
    @GetMapping("/qnaAdd.do")
    public String qnaAdd() {
        return "qnaAdd"; 
    }
    
    // Q&A 상세보기
    @GetMapping("/qnaDetail.do")
    public String qnaDetail() {
        return "qnaDetail"; 
    }
    
    // Q&A 수정
    @GetMapping("/qnaMod.do")
    public String qnaMod() {
        return "qnaMod"; 
    }
    
    @GetMapping("/qnaUpdate.do")
    public String qnaUpdate() {
        return "qnaUpdate"; 
    }
    
    // Q&A 삭제
    @GetMapping("/qnaDelete.do")
    public String qnaDelete() {
        return "qnaList"; 
    }
    
    // Q&A 댓글 목록
    @GetMapping("/replyList.do")
    public String replyList() {
    	return "replyList";
    }
    
    // Q&A 댓글 상세보기
    @GetMapping("/replyDetail.do")
    public String replyDetail() {
    	return "replyDetail";
    }
    
    /* 종합이용안내 */
    
    // 열차서비스
    @GetMapping("/trainService.do")
    public String trainService() {
    	return "trainService";
    }
    
    // 연계교통서비스
    @GetMapping("/linkService.do")
    public String linkService() {
    	return "linkService";
    }
    
    // 휠체어서비스
    @GetMapping("/wheelService.do")
    public String wheelService() {
    	return "wheelService";
    }
    
    /* 승차권 이용안내 */
    
    // 승차권 구입/환불/분실
    @GetMapping("/ticketManagement.do")
    public String ticketManagement() {
    	return "ticketManagement";
    }
    
    // 열차지연/ 운행중지
    @GetMapping("/trainDelayStop.do")
    public String trainDelayStop() {
    	return "trainDelayStop";
    }
    
    // 열차운임 및 시간표
    @GetMapping("/trainFaresTime.do")
    public String trainFaresTime() {
    	return "trainFaresTime";
    }
    
    /* 지연배상신청 */
    
    // 열차지연 시 교통비 지급 안내문
    @GetMapping("/trainDelayRefund.do")
    public String trainDelayRefund() {
    	return "trainDelayRefund";
    }
    
    // 지연료 계좌반환 신청
    @GetMapping("/delayCompensationRequest.do")
    public String delayCompensationRequest() {
    	return "delayCompensationRequest";
    }
    
    /* 서비스 예약 */
    
    // 서비스 예약
    @GetMapping("/serviceReservation.do")
    public String serviceReservation() {
    	return "serviceReservation";
    }
}