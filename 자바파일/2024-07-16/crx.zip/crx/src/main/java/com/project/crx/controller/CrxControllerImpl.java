package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CrxControllerImpl {

    @GetMapping("/map.do")
    public String main() {
        return "map"; 
    }
    
    @GetMapping("/silsigan.do")
    public String silsigan() {
        return "silsigan"; 
    }
    
    @GetMapping("/mapapi.do")
    public String mapapi() {
        return "mapapi"; 
    }
    
    @GetMapping("/mapmarker.do")
    public String mapmarker() {
        return "mapmarker"; 
    }
}