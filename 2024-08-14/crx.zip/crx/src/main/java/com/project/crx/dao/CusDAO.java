package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.CusVO;

@Mapper
@Repository("CusDAO")
public interface CusDAO {

	List<CusVO> noticeList() throws Exception;
	
}
