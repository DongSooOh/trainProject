package com.project.crx.controller;

import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface CusController {

	/* 고객안내 */
	
	/* 공지사항 */
	
	// 공지사항 목록
	ModelAndView noticeList(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
}
