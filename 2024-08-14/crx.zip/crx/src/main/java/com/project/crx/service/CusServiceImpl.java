package com.project.crx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.CusDAO;
import com.project.crx.vo.CusVO;

@Service
public class CusServiceImpl implements CusService {
	
	// DAO 연결
	@Autowired
	private CusDAO cusDAO;

	@Override
	public List<CusVO> noticeList() throws Exception {
		return cusDAO.noticeList();
	}
}
