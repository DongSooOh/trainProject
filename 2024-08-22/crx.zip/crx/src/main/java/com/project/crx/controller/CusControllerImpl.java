package com.project.crx.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.CusService;
import com.project.crx.vo.CusVO;
import com.project.crx.vo.Pagination;
import com.project.crx.vo.Search;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class CusControllerImpl implements CusController {
	
	// Service 연결
	@Autowired
	private CusService cusService;
	
	// VO 연결
	@Autowired
	private CusVO cusVO;
    
	/* 고객안내 */
	
    /* 공지사항 */			
	
    // 공지사항 목록
	@Override
    @GetMapping("/noticeList.do")
    public ModelAndView noticeList(@RequestParam(value = "page", defaultValue = "1") int page,
                                   @RequestParam(value = "searchType", required = false) String searchType,
                                   @RequestParam(value = "keyword", required = false) String keyword,
                                   HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView mav = new ModelAndView("/noticeList");

        Search search = new Search();
        search.setSearchType(searchType);
        search.setKeyword(keyword);
        search.setPage(page);

        int listCnt = cusService.getNoticeCnt(search);

        Pagination pagination = new Pagination();
        pagination.pageInfo(page, listCnt);

        List<CusVO> noticeList = cusService.noticeList(search);

        mav.addObject("noticeList", noticeList);
        mav.addObject("pagination", pagination);
        mav.addObject("search", search);
        return mav;
    }
    
    // 공지사항 등록
    @GetMapping("/noticeAdd.do")
    public ModelAndView noticeAdd() {
        ModelAndView mav = new ModelAndView("noticeAdd");
    	return mav; 
    }
    
    // 공지사항 등록 처리
    @Override
    @PostMapping("/noticeAdd.do")
    public ModelAndView noticeAdd(@RequestParam("notitle") String title,
                                  @RequestParam("nocontent") String content,
                                  @RequestParam("nofile") String filename,
                                  HttpServletRequest request, 
                                  HttpServletResponse response, 
                                  RedirectAttributes rAttr) throws Exception {

        ModelAndView mav = new ModelAndView();

        try {
            CusVO cusVO = new CusVO();
            cusVO.setNotitle(title);
            cusVO.setNocontent(content);
            cusVO.setNohit(0);

            LocalDate now = LocalDate.now();
            Date nodate = Date.valueOf(now);
            cusVO.setNodate(nodate);

            int userid = (Integer) request.getSession().getAttribute("userid");
            cusVO.setUserid(userid);

            // 파일이 존재하면 처리
            if (filename != null && !filename.isEmpty()) {
                cusVO.setFilename(filename); // 파일 이름을 VO에 저장

                String uploadDir = "C:/uploads/";
                Path path = Paths.get(uploadDir + filename);

                // 디렉토리가 존재하지 않으면 생성
                if (!Files.exists(path.getParent())) {
                    Files.createDirectories(path.getParent());
                }

                // 파일 저장 로직 (이 부분은 실제 파일 업로드 로직에 따라 달라질 수 있습니다)
                File file = new File(uploadDir + filename);
                file.createNewFile(); // 빈 파일을 생성

                cusVO.setFilepath(path.toString()); // 파일 경로 설정
            }

            // 게시글 저장
            cusService.noticeAdd(cusVO);

            mav.addObject("message", "공지사항이 등록되었습니다.");
            mav.setViewName("redirect:/noticeList.do");
        } catch (Exception e) {
            e.printStackTrace();
            mav.addObject("message", "공지사항 등록에 실패했습니다.");
            mav.setViewName("noticeAdd");
        }
        return mav;
    }
    
    // 공지사항 상세보기
    @Override
    @GetMapping("/noticeDetail.do")
    public ModelAndView noticeDetail(@RequestParam("nono") int nono, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ModelAndView mav = new ModelAndView("noticeDetail");
    	try {
    		// 조회수 증가
    		cusService.noticeHit(nono);
    		// nono를 전달하여 해당 공지사항 상세보기
    		CusVO cusVO = cusService.noticeDetail(nono);
    		// cusVO 객체를 noticeDetail 속성으로 추가
    		mav.addObject("noticeDetail", cusVO);
    	} catch(Exception e) {
    		e.printStackTrace();
    		mav.addObject("message", "공지사항 정보를 불러오는 데 실패했습니다.");
    	}
    	return mav; 
    }
    
    // 공지사항 수정
    @GetMapping("/noticeMod.do")
    public ModelAndView noticeMod(@RequestParam("nono") int nono, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	CusVO cusVO = cusService.noticeDetail(nono);
    	ModelAndView mav = new ModelAndView("/noticeMod");
    	mav.addObject("noticeMod", cusVO);
        return mav;
    }
    
    // 공지사항 수정 처리
    @Override
    @PostMapping("/noticeUpdate.do")
    public ModelAndView noticeUpdate(@ModelAttribute("cusVO") CusVO cusVO,
                                     @RequestParam("nono") int nono,
                                     @RequestParam("nofile") MultipartFile file,  
                                     HttpServletRequest request, HttpServletResponse response,
                                     RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        try {
            // 새로운 파일이 업로드되었는지 확인
            if (!file.isEmpty()) {
                String fileName = file.getOriginalFilename();
                cusVO.setFilename(fileName);

                byte[] bytes = file.getBytes();
                String uploadDir = "C:/uploads/"; // 실제 파일이 저장될 경로
                Path path = Paths.get(uploadDir + fileName);

                // 디렉토리가 존재하지 않으면 생성
                if (!Files.exists(path.getParent())) {
                    Files.createDirectories(path.getParent());
                }

                // 기존 파일이 존재하면 삭제
                CusVO existingVO = cusService.noticeDetail(nono);
                if (existingVO.getFilename() != null) {
                    Path existingFilePath = Paths.get(uploadDir + existingVO.getFilename());
                    Files.deleteIfExists(existingFilePath);
                }

                // 새로운 파일 저장
                Files.write(path, bytes);

                // 파일 경로도 VO에 설정
                cusVO.setFilepath(path.toString());
            } else {
                // 파일이 없을 경우 기존 파일명을 유지
                CusVO existingVO = cusService.noticeDetail(nono);
                cusVO.setFilename(existingVO.getFilename());
                cusVO.setFilepath(existingVO.getFilepath());
            }

            // 데이터베이스에 업데이트
            cusService.noticeUpdate(cusVO);

            mav.setViewName("redirect:/noticeDetail.do?nono=" + nono);
            rAttr.addFlashAttribute("message", "공지사항이 수정되었습니다.");
        } catch (Exception e) {
            e.printStackTrace();
            mav.addObject("message", "공지사항 수정에 실패했습니다.");
            mav.setViewName("noticeDetail.do");
        }
        return mav;
    }

    
    // 공지사항 삭제
    @Override
    @GetMapping("/noticeDelete.do")
    public ModelAndView noticeDelete(@RequestParam("nono") int nono, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        try {
        	CusVO cusVO = cusService.noticeDetail(nono);
        	cusService.noticeDelete(nono);
        	mav.setViewName("redirect:/noticeList.do");
        	rAttr.addFlashAttribute("message", "공지사항이 삭제되었습니다.");
        } catch(SQLException e) {
        	e.printStackTrace();
        	mav.setViewName("noticeList");
        	mav.addObject("message", "공지사항 삭제에 실패하였습니다.");
        }
    	return mav; 
    }
    
    
    /* FAQ */

	// FAQ 목록
	@Override
	@GetMapping("/faqList.do")
	public ModelAndView faqList(@RequestParam(value = "page", defaultValue = "1") int page,
	                            @RequestParam(value = "searchType", required = false) String searchType,
	                            @RequestParam(value = "keyword", required = false) String keyword,
	                            HttpServletRequest request, HttpServletResponse response) throws Exception {
	    ModelAndView mav = new ModelAndView("/faqList");
	
	    Search search = new Search();
	    search.setSearchType(searchType);
	    search.setKeyword(keyword);
	    search.setPage(page);
	
	    int listCnt = cusService.getFaqCnt(search);
	
	    Pagination pagination = new Pagination();
	    pagination.pageInfo(page, listCnt);
	
	    List<CusVO> faqList = cusService.faqList(search);
	
	    mav.addObject("faqList", faqList);
	    mav.addObject("pagination", pagination);
	    mav.addObject("search", search);
	    return mav;
	}
	
	// FAQ 등록
	@GetMapping("/faqAdd.do")
	public ModelAndView faqAdd() {
	    ModelAndView mav = new ModelAndView("faqAdd");
	    return mav; 
	}
	
	// FAQ 등록 처리
	@Override
	@PostMapping("/faqAdd.do")
	public ModelAndView faqAdd(@RequestParam("faqtitle") String title,
	                           @RequestParam("faqcontent") String content,
	                           HttpServletRequest request, 
	                           HttpServletResponse response, 
	                           RedirectAttributes rAttr) throws Exception {
	
	    ModelAndView mav = new ModelAndView();
	
	    try {
	        CusVO cusVO = new CusVO();
	        cusVO.setFaqtitle(title);
	        cusVO.setFaqcontent(content);
	        cusVO.setFaqhit(0);
	
	        LocalDate now = LocalDate.now();
	        Date faqdate = Date.valueOf(now);
	        cusVO.setFaqdate(faqdate);
	
	        int userid = (Integer) request.getSession().getAttribute("userid");
	        cusVO.setUserid(userid);
	
	        // FAQ 저장
	        cusService.faqAdd(cusVO);
	
	        mav.addObject("message", "FAQ가 등록되었습니다.");
	        mav.setViewName("redirect:/faqList.do");
	    } catch (Exception e) {
	        e.printStackTrace();
	        mav.addObject("message", "FAQ 등록에 실패했습니다.");
	        mav.setViewName("faqAdd");
	    }
	    return mav;
	}
	
	// FAQ 상세보기
	@Override
	@GetMapping("/faqDetail.do")
	public ModelAndView faqDetail(@RequestParam("faqno") int faqno, HttpServletRequest request, HttpServletResponse response) throws Exception {
	    ModelAndView mav = new ModelAndView("faqDetail");
	    try {
	        // 조회수 증가
	        cusService.faqHit(faqno);
	        // faqno를 전달하여 해당 FAQ 상세보기
	        CusVO cusVO = cusService.faqDetail(faqno);
	        // cusVO 객체를 faqDetail 속성으로 추가
	        mav.addObject("faqDetail", cusVO);
	    } catch(Exception e) {
	        e.printStackTrace();
	        mav.addObject("message", "FAQ 정보를 불러오는 데 실패했습니다.");
	    }
	    return mav; 
	}
	
	// FAQ 수정
	@GetMapping("/faqMod.do")
	public ModelAndView faqMod(@RequestParam("faqno") int faqno, HttpServletRequest request, HttpServletResponse response) throws Exception {
	    CusVO cusVO = cusService.faqDetail(faqno);
	    ModelAndView mav = new ModelAndView("/faqMod");
	    mav.addObject("faqMod", cusVO);
	    return mav;
	}
	
	// FAQ 수정 처리
	@Override
	@PostMapping("/faqUpdate.do")
	public ModelAndView faqUpdate(@ModelAttribute("cusVO") CusVO cusVO,
	                              @RequestParam("faqno") int faqno,
	                              HttpServletRequest request, HttpServletResponse response,
	                              RedirectAttributes rAttr) throws Exception {
	    ModelAndView mav = new ModelAndView();
	    try {
	        // 데이터베이스에 업데이트
	        cusService.faqUpdate(cusVO);
	
	        mav.setViewName("redirect:/faqDetail.do?faqno=" + faqno);
	        rAttr.addFlashAttribute("message", "FAQ가 수정되었습니다.");
	    } catch (Exception e) {
	        e.printStackTrace();
	        mav.addObject("message", "FAQ 수정에 실패했습니다.");
	        mav.setViewName("faqDetail.do");
	    }
	    return mav;
	}
	
	// FAQ 삭제
	@Override
	@GetMapping("/faqDelete.do")
	public ModelAndView faqDelete(@RequestParam("faqno") int faqno, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
	    ModelAndView mav = new ModelAndView();
	    try {
	        cusService.faqDelete(faqno);
	        mav.setViewName("redirect:/faqList.do");
	        rAttr.addFlashAttribute("message", "FAQ가 삭제되었습니다.");
	    } catch(SQLException e) {
	        e.printStackTrace();
	        mav.setViewName("faqList");
	        mav.addObject("message", "FAQ 삭제에 실패하였습니다.");
	    }
	    return mav; 
	}
    
	
    /* 고객센터 */
    
    // 공지사항
    @GetMapping("/customerservice.do")
    public String customerservice() {
        return "customerservice"; 
    }
    
    
    /* 유실물 안내 */

	// 유실물 안내 목록
	@Override
	@GetMapping("/lostList.do")
	public ModelAndView lostList(@RequestParam(value = "page", defaultValue = "1") int page,
	                             @RequestParam(value = "searchType", required = false) String searchType,
	                             @RequestParam(value = "keyword", required = false) String keyword,
	                             HttpServletRequest request, HttpServletResponse response) throws Exception {
	    ModelAndView mav = new ModelAndView("/lostList");
	
	    Search search = new Search();
	    search.setSearchType(searchType);
	    search.setKeyword(keyword);
	    search.setPage(page);
	
	    int listCnt = cusService.getLostCnt(search);
	
	    Pagination pagination = new Pagination();
	    pagination.pageInfo(page, listCnt);
	
	    List<CusVO> lostList = cusService.lostList(search);
	
	    mav.addObject("lostList", lostList);
	    mav.addObject("pagination", pagination);
	    mav.addObject("search", search);
	    return mav;
	}
	
	// 유실물 안내 등록
	@GetMapping("/lostAdd.do")
	public ModelAndView lostAdd() {
	    ModelAndView mav = new ModelAndView("lostAdd");
	    return mav; 
	}
	
	// 유실물 안내 등록 처리
	@Override
	@PostMapping("/lostAdd.do")
	public ModelAndView lostAdd(@RequestParam("losttitle") String title,
	                            @RequestParam("lostcontent") String content,
	                            @RequestParam("lostplace") String place,
	                            HttpServletRequest request, HttpServletResponse response, 
	                            RedirectAttributes rAttr) throws Exception {
	
	    ModelAndView mav = new ModelAndView();
	
	    try {
	        CusVO cusVO = new CusVO();
	        cusVO.setLosttitle(title);
	        cusVO.setLostcontent(content);
	        cusVO.setLostplace(place);
	        cusVO.setLosthit(0);
	
	        LocalDate now = LocalDate.now();
	        Date lostdate = Date.valueOf(now);
	        cusVO.setLostdate(lostdate);
	
	        int userid = (Integer) request.getSession().getAttribute("userid");
	        cusVO.setUserid(userid);
	
	        // 유실물 안내 저장
	        cusService.lostAdd(cusVO);
	
	        mav.addObject("message", "유실물 안내가 등록되었습니다.");
	        mav.setViewName("redirect:/lostList.do");
	    } catch (Exception e) {
	        e.printStackTrace();
	        mav.addObject("message", "유실물 안내 등록에 실패했습니다.");
	        mav.setViewName("lostAdd");
	    }
	    return mav;
	}
	
	// 유실물 안내 상세보기
	@Override
	@GetMapping("/lostDetail.do")
	public ModelAndView lostDetail(@RequestParam("lostno") int lostno, HttpServletRequest request, HttpServletResponse response) throws Exception {
	    ModelAndView mav = new ModelAndView("lostDetail");
	    try {
	        // 조회수 증가
	        cusService.lostHit(lostno);
	        // lostno를 전달하여 해당 유실물 안내 상세보기
	        CusVO cusVO = cusService.lostDetail(lostno);
	        // cusVO 객체를 lostDetail 속성으로 추가
	        mav.addObject("lostDetail", cusVO);
	    } catch(Exception e) {
	        e.printStackTrace();
	        mav.addObject("message", "유실물 안내 정보를 불러오는 데 실패했습니다.");
	    }
	    return mav; 
	}
	
	// 유실물 안내 삭제
	@Override
	@GetMapping("/lostDelete.do")
	public ModelAndView lostDelete(@RequestParam("lostno") int lostno, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
	    ModelAndView mav = new ModelAndView();
	    try {
	        cusService.lostDelete(lostno);
	        mav.setViewName("redirect:/lostList.do");
	        rAttr.addFlashAttribute("message", "유실물 안내가 삭제되었습니다.");
	    } catch(SQLException e) {
	        e.printStackTrace();
	        mav.setViewName("lostList");
	        mav.addObject("message", "유실물 안내 삭제에 실패하였습니다.");
	    }
	    return mav; 
	}
    
	
    /* 안내사항 */
    
    // 안내사항
    @GetMapping("/guideline.do")
    public String guideline() {
        return "guideline"; 
    }
    
    
    /* Q&A */
    
    // Q&A 목록
    @GetMapping("/qnaList.do")
    public ModelAndView qnaList(@RequestParam(value = "page", defaultValue = "1") int page,
                                @RequestParam(value = "searchType", required = false) String searchType,
                                @RequestParam(value = "keyword", required = false) String keyword,
                                HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView mav = new ModelAndView("qnaList");

        Search search = new Search();
        search.setSearchType(searchType);
        search.setKeyword(keyword);
        search.setPage(page);

        int listCnt = cusService.getQnaCnt(search);

        Pagination pagination = new Pagination();
        pagination.pageInfo(page, listCnt);

        List<CusVO> qnaList = cusService.qnaList(search);

        mav.addObject("qnaList", qnaList);
        mav.addObject("pagination", pagination);
        mav.addObject("search", search);
        return mav;
    }

    // Q&A 등록
 	@GetMapping("/qnaAdd.do")
 	public ModelAndView qnaAdd() {
 	    ModelAndView mav = new ModelAndView("qnaAdd");
 	    return mav; 
 	}
    
    // Q&A 질문 등록 처리
    @PostMapping("/qnaAdd.do")
    public ModelAndView qnaAdd(@ModelAttribute("cusVO") CusVO cusVO,
                               RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        cusService.qnaAdd(cusVO);
        rAttr.addFlashAttribute("message", "질문이 등록되었습니다.");
        mav.setViewName("redirect:/qnaList.do");
        return mav;
    }

    // Q&A 질문 상세보기
    @GetMapping("/qnaDetail.do")
    public ModelAndView qnaDetail(@RequestParam("qno") int qno) throws Exception {
        ModelAndView mav = new ModelAndView("qnaDetail");
        CusVO qnaDetail = cusService.qnaDetail(qno);
        List<CusVO> replyList = cusService.replyList(qno);

        mav.addObject("qnaDetail", qnaDetail);
        mav.addObject("replyList", replyList);
        return mav;
    }

    // Q&A 질문 수정
    @GetMapping("/qnaMod.do")
    public ModelAndView qnaMod(@RequestParam("qno") int qno, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        try {
            // 질문 정보 가져오기 (서비스에서 qno로 조회)
            CusVO cusVO = cusService.qnaDetail(qno);
            if (cusVO == null) {
                rAttr.addFlashAttribute("message", "해당 질문을 찾을 수 없습니다.");
                mav.setViewName("redirect:/qnaList.do");
            } else {
                mav.addObject("cusVO", cusVO);
                mav.setViewName("qnaMod");  // 수정 페이지로 이동
            }
        } catch (Exception e) {
            e.printStackTrace();
            rAttr.addFlashAttribute("message", "질문 수정 페이지를 로드하는 데 실패했습니다.");
            mav.setViewName("redirect:/qnaList.do");
        }
        return mav;
    }

    // Q&A 질문 수정 처리
    @PostMapping("/qnaUpdate.do")
    public ModelAndView qnaUpdate(@ModelAttribute("cusVO") CusVO cusVO,
                                  RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        try {
            // 서비스에서 질문 업데이트 처리
            cusService.qnaUpdate(cusVO);
            rAttr.addFlashAttribute("message", "질문이 수정되었습니다.");
            mav.setViewName("redirect:/qnaDetail.do?qno=" + cusVO.getQno());
        } catch (Exception e) {
            e.printStackTrace();
            mav.addObject("message", "질문 수정에 실패했습니다.");
            mav.setViewName("redirect:/qnaMod.do?qno=" + cusVO.getQno());
        }
        return mav;
    }
    
    // Q&A 질문 삭제
    @GetMapping("/qnaDelete.do")
    public ModelAndView qnaDelete(@RequestParam("qno") int qno,
                                  RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        cusService.qnaDelete(qno);
        rAttr.addFlashAttribute("message", "질문이 삭제되었습니다.");
        mav.setViewName("redirect:/qnaList.do");
        return mav;
    }

    // Q&A 답변 등록
    @GetMapping("/replyAdd.do")
    public ModelAndView replyAddPage(@RequestParam(value = "qno", required = true) int qno) throws Exception {
        if (qno == 0) {
            throw new IllegalArgumentException("Invalid Qno parameter");
        }
        ModelAndView mav = new ModelAndView("replyAdd");
        mav.addObject("qno", qno); // 질문 번호를 넘겨서 답변 작성 시 사용할 수 있도록 함
        return mav;
    }

    
    // Q&A 답변 등록 처리
    @PostMapping("/replyAdd.do")
    public ModelAndView replyAdd(@ModelAttribute("cusVO") CusVO cusVO, RedirectAttributes rAttr) throws Exception {
     
        ModelAndView mav = new ModelAndView();
        cusService.replyAdd(cusVO);
        rAttr.addFlashAttribute("message", "답변이 등록되었습니다.");
        mav.setViewName("redirect:/qnaDetail.do?qno=" + cusVO.getQna_qno());
        return mav;
    }


    // Q&A 답변 수정 추가
    @PostMapping("/replyUpdate.do")
    public ModelAndView replyUpdate(@ModelAttribute("cusVO") CusVO cusVO,
                                    RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        cusService.replyUpdate(cusVO);
        rAttr.addFlashAttribute("message", "답변이 수정되었습니다.");
        mav.setViewName("redirect:/qnaDetail.do?qno=" + cusVO.getQna_qno());
        return mav;
    }

    // Q&A 답변 삭제
    @GetMapping("/replyDelete.do")
    public ModelAndView replyDelete(@RequestParam("rno") int rno,
                                    @RequestParam("qno") int qno,
                                    RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        cusService.replyDelete(rno);
        rAttr.addFlashAttribute("message", "답변이 삭제되었습니다.");
        mav.setViewName("redirect:/qnaDetail.do?qno=" + qno);
        return mav;
    }
}