package com.project.crx.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.CusService;
import com.project.crx.vo.CusVO;

@Controller
public class FileController {

    @Autowired
    private CusService cusService;

    @Value("${upload.path}")
    private String uploadPath;

    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam("nofile") MultipartFile file, CusVO cusVO, RedirectAttributes redirectAttributes) throws Exception {
        try {
            if (!file.isEmpty()) {
                // 디렉토리가 존재하지 않으면 생성
                File dir = new File(uploadPath);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                String originalFilename = file.getOriginalFilename();
                String filepath = uploadPath + File.separator + originalFilename;

                // 파일을 해당 경로에 저장
                File saveFile = new File(filepath);
                file.transferTo(saveFile);

                // CusVO 객체에 파일 이름과 경로 설정
                cusVO.setFilename(originalFilename);
                cusVO.setFilepath(filepath);
            }

            // 게시글 저장 (파일이 없는 경우에도 게시글이 저장됨)
            cusService.noticeAdd(cusVO);
            redirectAttributes.addFlashAttribute("message", "공지사항이 등록되었습니다.");

        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("message", "파일 업로드 실패!");
            return "redirect:/noticeAdd.do";
        }

        return "redirect:/noticeList.do";
    }

    @GetMapping("/downloadFile")
    public ResponseEntity<Resource> downloadFile(@RequestParam("filename") String filename) {
        try {
            // 파일명 URL 디코딩
            String decodedFilename = URLDecoder.decode(filename, StandardCharsets.UTF_8.name());
            System.out.println("Decoded filename: " + decodedFilename); // 디코딩된 파일명 출력

            File file = new File("C:/path/to/your/files/" + decodedFilename);
            if (!file.exists()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }

            FileInputStream inputStream = new FileInputStream(file);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + decodedFilename);

            return ResponseEntity.ok()
                                 .headers(headers)
                                 .body(new InputStreamResource(inputStream));
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
