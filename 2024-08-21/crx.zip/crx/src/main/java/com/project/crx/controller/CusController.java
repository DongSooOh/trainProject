package com.project.crx.controller;


import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.vo.CusVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface CusController {
	
	/* 고객안내 */
	
	/* 공지사항 */

	// 공지사항 목록
	ModelAndView noticeList(@RequestParam(value = "page", defaultValue = "1") int page,
            				@RequestParam(value = "searchType", required = false) String searchType,
            				@RequestParam(value = "keyword", required = false) String keyword,
            				HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 공지사항 등록
	ModelAndView noticeAdd(@RequestParam("notitle") String title,
			  			   @RequestParam("nocontent") String content,
			  			   @RequestParam("nofile") MultipartFile file,  
			  			   HttpServletRequest request, 
			  			   HttpServletResponse response, 
			  			   RedirectAttributes rAttr) throws Exception; 
	
	// 공지사항 상세보기
	ModelAndView noticeDetail(int nono, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 공지사항 수정
	ModelAndView noticeUpdate(CusVO cusVO, int nono, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception;
	
	// 공지사항 삭제
	ModelAndView noticeDelete(int nono, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception;
}
