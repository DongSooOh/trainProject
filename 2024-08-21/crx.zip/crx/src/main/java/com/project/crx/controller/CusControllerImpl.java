package com.project.crx.controller;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.dao.CusDAO;
import com.project.crx.service.CusService;
import com.project.crx.vo.CusVO;
import com.project.crx.vo.Pagination;
import com.project.crx.vo.Search;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class CusControllerImpl implements CusController {
	
	// Service 연결
	@Autowired
	private CusService cusService;
	
	// VO 연결
	@Autowired
	private CusVO cusVO;
	
	// DAO 연결(Mapper)
	@Autowired
	private CusDAO cusDAO;
    
	/* 고객안내 */
	
	/* 게시판 공통 */
	
	// 검색
//	@GetMapping("/search.do")
//	public ModelAndView search(@RequestParam(value="type", required=false) String type,
//						 @RequestParam(value="keyword", required=false) String keyword,
//						 @RequestParam(required = false, defaultValue= "1") int num) throws Exception {
//		ModelAndView mav = new ModelAndView();
//		
//		if (type != null && keyword != null) {
//			cusService.selectSearch(mav.getModel(), type, keyword, num);
//		} else {
//			cusService.boardList(mav.getModel(), num);
//		}
//		mav.setViewName("noticeList.do");
//		return mav;
//	}
	
    /* 공지사항 */			
	
    // 공지사항 목록
	@Override
    @GetMapping("/noticeList.do")
    public ModelAndView noticeList(@RequestParam(value = "page", defaultValue = "1") int page,
                                   @RequestParam(value = "searchType", required = false) String searchType,
                                   @RequestParam(value = "keyword", required = false) String keyword,
                                   HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView mav = new ModelAndView("/noticeList");

        Search search = new Search();
        search.setSearchType(searchType);
        search.setKeyword(keyword);
        search.setPage(page);

        int listCnt = cusService.getBoardListCnt(search);

        Pagination pagination = new Pagination();
        pagination.pageInfo(page, listCnt);

        List<CusVO> noticeList = cusService.noticeList(search);

        mav.addObject("noticeList", noticeList);
        mav.addObject("pagination", pagination);
        mav.addObject("search", search);
        return mav;
    }
    
    // 공지사항 작성
    @GetMapping("/noticeAdd.do")
    public ModelAndView noticeAdd() {
        ModelAndView mav = new ModelAndView("noticeAdd");
    	return mav; 
    }
    
    // 공지사항 등록
    @Override
    @PostMapping("/noticeAdd.do")
    public ModelAndView noticeAdd(@RequestParam("notitle") String title,
                                  @RequestParam("nocontent") String content,
                                  @RequestParam("nofile") MultipartFile file,  // 파일을 받기 위한 추가
                                  HttpServletRequest request, 
                                  HttpServletResponse response, 
                                  RedirectAttributes rAttr) throws Exception {

        ModelAndView mav = new ModelAndView();

        try {
            CusVO cusVO = new CusVO();
            cusVO.setNotitle(title);
            cusVO.setNocontent(content);
            cusVO.setNohit(0);

            LocalDate now = LocalDate.now();
            Date nodate = Date.valueOf(now);
            cusVO.setNodate(nodate);

            int userid = (Integer) request.getSession().getAttribute("userid");
            cusVO.setUserid(userid);

            // 파일이 존재하면 처리
            if (!file.isEmpty()) {
                String fileName = file.getOriginalFilename();
                cusVO.setFilename(fileName); // 파일 이름을 VO에 저장

                byte[] bytes = file.getBytes();
                String uploadDir = "/uploads/";
                Path path = Paths.get(uploadDir + fileName);
                Files.write(path, bytes);

                // 파일 경로도 필요하다면 여기에 추가로 설정할 수 있습니다.
                cusVO.setFilepath(path.toString()); // 파일 경로 설정 (선택 사항)
            }

            // 게시글 저장
            cusService.noticeAdd(cusVO);

            mav.addObject("message", "공지사항이 등록되었습니다.");
            mav.setViewName("redirect:/noticeList.do");
        } catch (Exception e) {
            e.printStackTrace();
            mav.addObject("message", "공지사항 등록에 실패했습니다.");
            mav.setViewName("noticeAdd");
        }
        return mav;
    }
    
    // 공지사항 상세보기
    @Override
    @GetMapping("/noticeDetail.do")
    public ModelAndView noticeDetail(@RequestParam("nono") int nono, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ModelAndView mav = new ModelAndView("noticeDetail");
    	try {
    		// 조회수 증가
    		cusService.hitChk(nono);
    		// nono를 전달하여 해당 공지사항 상세보기
    		CusVO cusVO = cusService.noticeDetail(nono);
    		// cusVO 객체를 noticeDetail 속성으로 추가
    		mav.addObject("noticeDetail", cusVO);
    	} catch(Exception e) {
    		e.printStackTrace();
    		mav.addObject("message", "공지사항 정보를 불러오는 데 실패했습니다.");
    	}
    	return mav; 
    }
    
    // 공지사항 수정
    @GetMapping("/noticeMod.do")
    public ModelAndView noticeMod(@RequestParam("nono") int nono, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	CusVO cusVO = cusService.noticeDetail(nono);
    	ModelAndView mav = new ModelAndView("/noticeMod");
    	mav.addObject("noticeMod", cusVO);
        return mav;
    }
    
    @Override
    @PostMapping("/noticeUpdate.do")
    public ModelAndView noticeUpdate(@ModelAttribute("cusVO") CusVO cusVO, @RequestParam("nono") int nono, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        try {
        	cusService.noticeUpdate(cusVO);
        	
        	mav.setViewName("redirect:/noticeDetail.do?nono=" + nono);
        	rAttr.addFlashAttribute("message", "공지사항이 수정되었습니다.");
        } catch(Exception e) {
        	e.printStackTrace();
        	mav.addObject("message", "공지사항 수정에 실패했습니다.");
        	mav.setViewName("noticeDetail.do");
        }
    	return mav; 
    }
    
    // 공지사항 삭제
    @Override
    @GetMapping("/noticeDelete.do")
    public ModelAndView noticeDelete(@RequestParam("nono") int nono, HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();
        try {
        	CusVO cusVO = cusService.noticeDetail(nono);
        	cusService.noticeDelete(nono);
        	mav.setViewName("redirect:/noticeList.do");
        	rAttr.addFlashAttribute("message", "공지사항이 삭제되었습니다.");
        } catch(SQLException e) {
        	e.printStackTrace();
        	mav.setViewName("noticeList");
        	mav.addObject("message", "공지사항 삭제에 실패하였습니다.");
        }
    	return mav; 
    }
    
    /* FAQ */
    
    // FAQ 목록
    @GetMapping("/faqList.do")
    public String faqList() {
        return "/faqList"; 
    }
    
    // FAQ 작성
    @GetMapping("/faqAdd.do")
    public String faqAdd() {
        return "/faqAdd"; 
    }
    
    // FAQ 상세보기
    @GetMapping("/faqDetail.do")
    public String faqDetail() {
        return "/faqDetail";
    }
    
    // FAQ 수정
    @GetMapping("/faqMod.do")
    public String faqMod() {
        return "/faqMod"; 
    }
    
    @GetMapping("/faqUpdate.do")
    public String faqUpdate() {
        return "faqUpdate"; 
    }
    
    // FAQ 삭제
    @GetMapping("/faqDelete.do")
    public String faqDelete() {
        return "/faqList"; 
    }
    
    /* 고객센터 */
    
    // 공지사항
    @GetMapping("/customerservice.do")
    public String customerservice() {
        return "customerservice"; 
    }
    
    /* 유실물 안내 */
    
    // 유실물 목록
    @GetMapping("/lostItemList.do")
    public String lostItemList() {
        return "/lostItemList"; 
    }
    
    // 유실물 작성
    @GetMapping("/lostItemAdd.do")
    public String lostItemAdd() {
        return "/lostItemAdd"; 
    }
    
    // 유실물 상세보기
    @GetMapping("/lostItemDetail.do")
    public String lostItemDetail() {
        return "/lostItemDetail";
    }
    
    /* 안내사항 */
    
    // 안내사항
    @GetMapping("/guideline.do")
    public String guideline() {
        return "guideline"; 
    }
    
    /* Q&A */
    
    // Q&A 목록
    @GetMapping("/qnaList.do")
    public String qnaList() {
        return "qnaList"; 
    }
    
    // Q&A 작성
    @GetMapping("/qnaAdd.do")
    public String qnaAdd() {
        return "qnaAdd"; 
    }
    
    // Q&A 상세보기
    @GetMapping("/qnaDetail.do")
    public String qnaDetail() {
        return "qnaDetail"; 
    }
    
    // Q&A 수정
    @GetMapping("/qnaMod.do")
    public String qnaMod() {
        return "qnaMod"; 
    }
    
    @GetMapping("/qnaUpdate.do")
    public String qnaUpdate() {
        return "qnaUpdate"; 
    }
    
    // Q&A 삭제
    @GetMapping("/qnaDelete.do")
    public String qnaDelete() {
        return "qnaList"; 
    }
    
    // Q&A 댓글 목록
    @GetMapping("/replyList.do")
    public String replyList() {
    	return "replyList";
    }
    
    // Q&A 댓글 상세보기
    @GetMapping("/replyDetail.do")
    public String replyDetail() {
    	return "replyDetail";
    }
}