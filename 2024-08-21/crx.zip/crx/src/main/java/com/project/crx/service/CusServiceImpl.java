package com.project.crx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.CusDAO;
import com.project.crx.vo.CusVO;
import com.project.crx.vo.Search;

@Service
public class CusServiceImpl implements CusService {
	
	// DAO 연결
	@Autowired
	private CusDAO cusDAO;

	/* 고객안내 */
	
	/* 게시판 공통 */
	
	// 검색
	
	
	/* 공지사항 */
	
	@Override
    public List<CusVO> noticeList(Search search) throws Exception {
        return cusDAO.noticeList(search);
    }

    @Override
    public int getBoardListCnt(Search search) throws Exception {
        return cusDAO.getBoardListCnt(search);
    }
	
	// 공지사항 등록
	@Override
	public void noticeAdd(CusVO cusVO) throws Exception {
		cusDAO.noticeAdd(cusVO);
	}
	
	// 공지사항 상세보기
	@Override
	public CusVO noticeDetail(int nono) throws Exception {
		return cusDAO.noticeDetail(nono);
	}
	
	// 공지사항 조회수 증가
	@Override
	public void hitChk(int nono) throws Exception {
		cusDAO.hitChk(nono);
	}
	
	// 공지사항 수정
	@Override
	public void noticeUpdate(CusVO cusVO) throws Exception {
		cusDAO.noticeUpdate(cusVO);
	}
	
	// 공지사항 삭제
	@Override
	public void noticeDelete(int nono) throws Exception {
		cusDAO.noticeDelete(nono);
	}
}
