package com.project.crx.vo;

import org.springframework.stereotype.Component;

@Component("InfoVO")
public class InfoVO {
	
	private String apply_num;	// 승차권 번호
	private int coin;			// 환불 예정 금액1(tour)
	private int totalCharge;	// 환불 예정 금액2(train)
	
	public String getApply_num() {
		return apply_num;
	}
	public void setApply_num(String apply_num) {
		this.apply_num = apply_num;
	}
	public int getCoin() {
		return coin;
	}
	public void setCoin(int coin) {
		this.coin = coin;
	}
	public int getTotalCharge() {
		return totalCharge;
	}
	public void setTotalCharge(int totalCharge) {
		this.totalCharge = totalCharge;
	}
}