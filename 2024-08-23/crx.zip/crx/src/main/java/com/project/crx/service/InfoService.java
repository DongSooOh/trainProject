package com.project.crx.service;

import com.project.crx.vo.InfoVO;

public interface InfoService {

	InfoVO getApplyNum(String apply_num) throws Exception;
}
s