package com.project.crx.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.InfoDAO;
import com.project.crx.vo.InfoVO;

@Service("infoService")
public class InfoServiceImpl implements InfoService {

    @Autowired
    private InfoDAO infoDAO;

    @Override
    public InfoVO getApplyNum(String apply_num) throws Exception {
        return infoDAO.getApplyNum(apply_num);
    }
}