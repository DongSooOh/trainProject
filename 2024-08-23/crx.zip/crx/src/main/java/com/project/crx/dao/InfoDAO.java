package com.project.crx.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.InfoVO;

@Mapper
@Repository("InfoDAO")
public interface InfoDAO {

	InfoVO getApplyNum(String apply_num) throws Exception;
}
