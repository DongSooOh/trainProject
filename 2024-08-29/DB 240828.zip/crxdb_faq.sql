-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 211.230.242.63    Database: crxdb
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq` (
  `faqno` int NOT NULL AUTO_INCREMENT,
  `faqtitle` varchar(50) DEFAULT NULL,
  `faqcontent` varchar(1000) DEFAULT NULL,
  `faqdate` date DEFAULT NULL,
  `faqhit` int DEFAULT NULL,
  `member_memid` int NOT NULL,
  PRIMARY KEY (`faqno`),
  KEY `fk_faq_member1_idx` (`member_memid`),
  CONSTRAINT `fk_faq_member1` FOREIGN KEY (`member_memid`) REFERENCES `member` (`memid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'[승차권] CRX 회원이 아닌데 승차권을 살 수 있나요?','CRX에서는 온라인 결제는 회원가입을 해야 이용이 가능하며, \r\n\r\n회원이 아니실 경우 현장에서 발권하여 이용해주시기 바랍니다.','2024-08-25',3,10006),(2,'[승차권] 승차권을 환불했는데 결제금액 환불은 언제되나요?','당일 결제, 당일 환불하신 경우 당일 취소 처리됩니다.(부분취소 제외)\r\n\r\n그 외의 경우는 결제하신 수단에 따라 환불소요기간이 다르며, 카드결제건의 경우 카드사마다 환불방식과 기간이 상이할 수 있음을 알려드립니다.\r\n\r\n- 신용카드 : 승차권 환불일로부터 약 5~7일 소요\r\n\r\n- 체크카드 : 승차권 환불일로부터 약 6~8일 소요\r\n\r\n- 계좌이체 : 승차권 환불일로부터 약 5~10일 소요','2024-08-25',1,10006),(3,'[역사 이용] 유실물 문의는 어디로 해야하나요?','1. 역에서 분실했거나 하차 직후 분실한 사실을 아셨다면, 해당 역 직원에게 즉시 문의해주시기 바랍니다.\r\n\r\n2. 열차 탑승 후 분실한 사실을 아셨다면, 승무원에게 즉시 문의해주시기 바랍니다.\r\n\r\n(CRX 홈페이지 챗봇으로 승무원 호출메시지 이용 가능)\r\n\r\n3. 하차 후 분실한 사실을 아셨다면, 유실물센터 또는 고객센터로 신고해주시기 바랍니다.\r\n\r\n<긴급 연락처>\r\n\r\n- 고객센터 : 1005-1005','2024-08-25',1,10006),(4,'[승차권] 구매한 승차권의 날짜와 시간을 변경하려면 어떻게 해야하나요?','CRX 홈페이지를 통해 예매하신 승차권을 변경하고자 하시는 경우, \r\n\r\n승차권을 환불하고 새로 예매하시거나, 매표창구에 방문하여 변경을 요청하여 주시기 바랍니다.\r\n\r\n단, 기존에 예매하신 승차권을 환불하고 새로 구입하실 때는 약관에 따라 위약금이 발생할 수 있습니다. \r\n\r\n역 창구에서 구입하신 승차권은 창구에서만 변경이 가능합니다.','2024-08-25',4,10006),(5,'[승차권] 승차권을 변경하고 싶어요.','승차권을 발권 받은 뒤, 열차시각, 구간, 좌석 등을 변경하는 방법은 다음과 같습니다.\r\n\r\n- CRX 홈페이지에서 발권 받은 승차권 : 승차권 환불 후 다시 구입\r\n\r\n- 역 창구에서 발권 받은 승차권 : 매표창구에 방문하여 변경 요청\r\n\r\n승차권을 환불 또는 변경할 경우, CRX 여객운송약관에 따라 위약금이 발생할 수 있습니다.','2024-08-25',8,10006);
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-28 17:17:13
