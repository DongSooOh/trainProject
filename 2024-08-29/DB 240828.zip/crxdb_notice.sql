-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 211.230.242.63    Database: crxdb
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `nono` int NOT NULL AUTO_INCREMENT,
  `notitle` varchar(100) DEFAULT NULL,
  `nocontent` varchar(1000) DEFAULT NULL,
  `nodate` date DEFAULT NULL,
  `filename` varchar(150) DEFAULT NULL,
  `filepath` varchar(10000) DEFAULT NULL,
  `nohit` int DEFAULT NULL,
  `member_memid` int NOT NULL,
  PRIMARY KEY (`nono`),
  KEY `fk_notice_member_idx_idx` (`member_memid`),
  CONSTRAINT `fk_notice_member_idx` FOREIGN KEY (`member_memid`) REFERENCES `member` (`memid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'집중호우에 따른 열차 운행 조정 및 지연안내','집중 호우에 따른 안전한 열차운행을 위해 일부 열차 운행 조정 및 지연이 예상됩니다.\r\n열차를 이용하시는 고객께서는 CRX 홈페이지, CRX 고객센터를 통해 열차운행 정보를 확인해주시기 바랍니다.\r\n\r\n□ 서대구역 미정차 열차 : CRX 306, 313, 319, 333, 334, 344열차\r\n- 서대구역 외 전 구간 정상 운행(지연운행 여부 확인 후 이용)\r\n- 서대구역 미정차에 따른 사용불가 승차권 위약금 없이 자동 반환 (현금 구매 승차권은 1년 이내 전국역에서 반환 가능)\r\n\r\n※ 기타 자세한 내용은 CRX 고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.\r\n\r\n2024. 8. 21. 주식회사 씨알엑스','2024-08-21',NULL,NULL,28,10004),(2,'고객감사제 이벤트 당첨자 발표일 안내','2024년 CRX 고객감사제에 관심 가져주신 모든 고객님들께 감사드립니다.\r\n\r\n기간 중 많은 CRX를 이용해주신 고객님들 대상으로 추첨을 통해\r\n\r\n아래와 같이 당첨자 발표 예정이니 이용에 참고하여 주시기 바랍니다.\r\n\r\n\r\n□ 추첨대상 : 고객감사제 기간 중 CRX를 이용한 고객\r\n\r\n\r\n□ 발 표 일 : 2024. 5. 22.(수) 14시 예정\r\n\r\n\r\n□ 경 품 : CRX굿즈, 여행상품 등\r\n\r\n\r\n부산투어 여행상품(2명)\r\n텀블러살균기(30명)\r\n보조배터리(100명)\r\n접이식 우산(100명)\r\n만년필(200명) * 기존 : 그립톡 → 변경 : 만년필\r\n\r\n\r\n□ 기타 자세한 내용은 CRX고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.\r\n\r\n\r\n주식회사 씨알엑스','2024-08-21',NULL,NULL,51,10004),(3,'인제역 엘리베이터 운행중지 알림','인제역 엘리베이터 운행중지 알림\r\n인제역 하행 엘리베이터 공사로\r\n인제역 출발/도착 휠체어석 이용이 제한되니\r\n이용에 참고하시기 바랍니다.\r\n\r\n◻︎ 제한기간 : 2024. 8. 23.(금) ~ 9. 11.(수)까지\r\n* 제한기간은 공사일정에 따라 변경 될 수 있음\r\n\r\n※ 기타 자세한 내용은 CRX 고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.\r\n\r\n주식회사 씨알엑스','2024-08-21',NULL,NULL,12,10004),(4,'예약 발매 시스템 점검 안내','예약 발매 시스템 점검 안내\r\n시스템 점검을 위하여 아래와 같이 서비스가 중지되오니,\r\n고객 여러분의 양해를 부탁드립니다.\r\n\r\n◻︎ 점검시간 : 2024. 8. 23.(금) 02:00 ~ 04:00\r\n\r\n◻︎ 이용제한 : 로그인, 회원가입, 승차권 및 열차조회 등 예약 발매 서비스\r\n\r\n※ 기타 자세한 내용은 CRX 고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.','2024-08-21',NULL,NULL,14,10004),(5,'승차권 예약 · 발매일 조정 알림','승차권 예약 · 발매일 조정 알림\r\nCRX 운행조정에 따른 통합열차 운행계획 변경에 따라\r\n다음과 같이 승차권 예발매일을 조정하오니 열차 이용에 참고하시기 바랍니다.\r\n\r\n◻︎ 대상열차 : 2024. 10. 24.(목) 이후 운행하는 CRX 전 열차\r\n\r\n◻︎ 승차권 예약 · 발매일 : 2023. 12. 14.(목) 14:00 \r\n\r\n◻︎ 기타 자세한 내용은 CRX 고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.\r\n\r\n2023. 11. 27.\r\n\r\n주식회사 씨알엑스','2024-08-21',NULL,NULL,7,10004),(6,'부정승차 단속 집중기간 운영안내','부정승차 단속 집중기간 운영안내\r\n\r\n올바른 승차권 이용문화 정착 및 선의의 고객 보호를 위해\r\n부정승차 집중 단속기간을 운영하오니, 열차 이용에 참고하시기 바랍니다.\r\n\r\n◻︎ 시행일 : 2024. 08. 01. (목) ~\r\n\r\n◻︎ 시행장소 : CRX 열차 내, CRX 전용역(화천역, 양구역, 인제역, 고성역, 속초역, 양양역)\r\n\r\n◻︎ 주요내용 : 특별기동검표단 활동, 승차권 부정사용 모니터링 등\r\n* 올바른 승차권 문화조성을 위해 고객 여러분의 적극적인 협조 바랍니다.\r\n\r\n※ 기타 자세한 내용은 CRX 고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.\r\n\r\n\r\n2024. 08. 01.\r\n\r\n주식회사 씨알엑스','2024-08-21',NULL,NULL,11,10004),(7,'CRX 열차 운임표 및 시간표 안내','□ 다음과 같이 CRX 열차 운임표 및 시간표를 첨부하였으니 \r\n\r\n이용간 참고하시기 바랍니다.\r\n\r\n※ 기타 문의사항은 CRX 고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.\r\n\r\n2024. 8. 25. 주식회사 씨알엑스','2024-08-25','CRX(노선,운임).JPG','C:\\uploads\\CRX(노선,운임).JPG',35,10000),(8,'간편 결제 서비스 일시 중지 안내','간편 결제 서비스 일시 중지 안내\r\n\r\n간편결제 연계 서버 점검에 따라,\r\n아래와 같이 관련 서비스가 일시 중지되오니\r\n고객 여러분의 양해를 부탁드립니다.\r\n\r\n◻︎ 점검시간 : 2024. 8. 25.(금) 00:00 ~ 05:00\r\n\r\n◻︎ 제한서비스 : 카카오페이, 네이버페이, 페이코 간편결제 서비스 일체\r\n\r\n◻︎ 안내사항 : 일반 신용카드 결제는 가능\r\n\r\n※ 기타 자세한 내용은 CRX 고객센터(☏1005-1005)에 문의하여 주시기 바랍니다.\r\n\r\n주식회사 씨알엑스','2024-08-25',NULL,NULL,3,10006),(9,'시스템 점검 안내','시스템 점검 안내\r\n\r\n시스템 점검을 위하여 아래와 같이\r\n서비스가 중지되오니 고객 여러분의 양해를 부탁드립니다.\r\n\r\n◻︎ 점검시간 : 8. 26.(월) 01:00 ~ 04:00\r\n\r\n◻︎ 이용제한: 로그인, 회원가입 등 회원 기반 예약 발매 서비스\r\n\r\n※ 기타 자세한 문의사항은 CRX 고객센터(☎1005-1005)로 문의해주시기 바랍니다. ※','2024-08-25',NULL,NULL,1,10005),(10,'CRX 회원가입 및 이용 관련 변경사항 알림','CRX 회원가입 및 이용 관련 변경사항 알림\r\n\r\nCRX 회원가입 및 이용과 관련하여 다음과 같이 조정하오니,\r\n고객 여러분께서는 CRX 이용에 참고하여 주시기 바랍니다.\r\n\r\n1. 회원탈퇴 시 재가입 기준 변경\r\n - 회원탈퇴 후 재가입 시 유예기간을 30일 부여 (탈퇴일로부터 30일간 재가입 불가)\r\n - 시행일 : 8월 1일부터\r\n\r\n2. 신규 가입쿠폰 지급 종료\r\n - 신규 회원가입 축하쿠폰(10%) 지급 종료\r\n - 시행일 : 9월 1일부터\r\n* 또한, 위 변경사항에 따라 기존 CRX 회원가입자의 본인확인정보(DI)는 탈퇴일로부터 30일간 보관됨을 안내드립니다.\r\n\r\n※ 기타 자세한 문의사항은 CRX 고객센터(1005-1005)로 문의해주시기 바랍니다. ※','2024-08-25',NULL,NULL,7,10005),(11,'CRX 고객센터 정상운영 알림','CRX 고객센터 정상운영 알림\r\n\r\n금일 통신사 장애로 일시 중단되었던\r\nCRX 고객센터(1005-1005) 업무는 현재 정상 운영되고 있습니다.\r\n\r\n\r\n○ 장애발생시간 : 2024. 8. 25.(일) 11:05 ~ 14:26\r\n\r\n\r\n※ 고객님께 불편을 드려 대단히 죄송합니다. ※','2024-08-25',NULL,NULL,16,10005);
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-28 17:17:12
