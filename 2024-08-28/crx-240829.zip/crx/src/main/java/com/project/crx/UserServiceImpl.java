package com.project.crx;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private KakaoRepository userRepository;

	@Override
	public User findByUsermail(String usermail) {
		// 이메일로 사용자 검색
		return userRepository.findByUsermail(usermail).orElse(null);
	}

	@Override
	public void saveUser(User user) {
		// 사용자 저장
		userRepository.save(user);
	}

	@Override
	public void updatePwdByMail(User user) {
		// 이메일로 기존 사용자 검색
		Optional<User> existingUserOpt = userRepository.findByUsermail(user.getUsermail());

		if (existingUserOpt.isPresent()) {
			User existingUser = existingUserOpt.get();

			// 기존 사용자의 비밀번호, level, status 업데이트
			if (user.getUserpwd() != null && !user.getUserpwd().trim().isEmpty()) {
				existingUser.setUserpwd(user.getUserpwd());
				existingUser.setLevel(user.getLevel());
				existingUser.setStatus(user.getStatus());

				// 업데이트된 사용자 저장
				userRepository.save(existingUser);
			} else {
				throw new IllegalArgumentException("비밀번호가 설정되지 않았습니다.");
			}
		} else {
			throw new IllegalArgumentException("해당 이메일로 사용자를 찾을 수 없습니다.");
		}
	}
}