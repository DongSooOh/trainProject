var stompClient = null;
var username = null;
var autoReplyEnabled = true; // 자동응답 기능 활성화 기본 상태

function connect() {
    username = document.getElementById("name").value.trim();

    if (username) {
        var socket = new SockJS('/ws');
        stompClient = Stomp.over(socket);

        stompClient.connect({}, onConnected, onError);
    }
}

function onConnected() {
    document.getElementById("username-page").style.display = 'none';
    document.getElementById("chat-page").style.display = 'block';

    stompClient.subscribe('/topic/public', onMessageReceived);

    stompClient.send("/app/chat.addUser", {}, JSON.stringify({sender: username, type: 'JOIN'}));

    // Send welcome message with HTML content
    sendWelcomeMessage();
}

function onError(error) {
    console.log('챗봇 서버에 연결할 수 없습니다. 다시 시도하려면 이 페이지를 새로고침하십시오');
}

function sendMessage() {
    var messageContent = document.getElementById("message").value.trim();

    if (messageContent && stompClient) {
        var chatMessage = {
            sender: username,
            content: messageContent,
            type: 'CHAT'
        };

        stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
        document.getElementById("message").value = '';

        // 자동 응답 처리
        if (username !== '챗봇') {
            handleAutoReply(messageContent);
        }
    }
}

function sendWelcomeMessage() {
    var welcomeMessage = {
        sender: '챗봇',
        content: `
            <img src="../img/logo.gif" style="width:80px"><br>환영합니다! CRX 챗봇서비스입니다.<br>
            궁금한 분야를 선택하시거나 대화창에 키워드로<br>질문하시면 답변해드립니다.<br>
            1.전화번호 : <a href="tel:1005-1005">1005-1005</a><br>
            2.홈페이지 : <a href="http://localhost:8080/main.do" target="_blank">CRX홈페이지</a><br>
            <button onclick="handleButtonClick('reserv')" class="button">승차권 예약 및 환불 안내</button>
            <button onclick="handleButtonClick('lost')" class="button">유실물 안내</button>
            <button onclick="handleButtonClick('FAQ')" class="button">자주하는 질문</button>
            <button onclick="handleButtonClick('tour')" class="button">관광열차 안내</button>
        `,
        type: 'CHAT'
    };

    stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(welcomeMessage));
}

function handleAutoReply(messageContent) {
    if (!autoReplyEnabled) {
        return; // 자동응답 비활성화 상태에서는 아무것도 하지 않음
    }

    var autoReply = '';

    if (messageContent.includes('안녕') || messageContent.includes('반가워')) {
        autoReply = '안녕하세요! 무엇을 도와드릴까요?';
    } else if (messageContent.includes('유실물')) {
        autoReply = '유실물 안내는 <a href="lostList.do" target="_blank">여기</a>에서 확인하실 수 있습니다.';
    } else if (messageContent.includes('예약') || messageContent.includes('환불')) {
        autoReply = '승차권 예약 및 환불 안내는 <a href="ticket.do" target="_blank">예약 페이지</a> 또는 </br><a href="ticketManagement.do" target="_blank">환불 페이지</a>에서 확인하실 수 있습니다.';
    } else if (messageContent.includes('자주 묻는 질문') || messageContent.includes('FAQ')) {
        autoReply = '자주 묻는 질문에 대한 답변은 <a href="faqList.do" target="_blank">여기</a>에서 확인하실 수 있습니다.';
    } else if (messageContent.includes('관광열차')) {
        autoReply = '관광열차 안내는 <a href="tourtrain.do" target="_blank">여기</a>에서 확인하실 수 있습니다.';
    } else if (messageContent.includes('잘가')) {
        autoReply = '감사합니다. 좋은 하루 되세요!';
    } else if (messageContent.includes('전화번호')) {
        autoReply = '고객센터 전화번호는 <a href="tel:1005-1005">1005-1005</a>입니다.';
    } else if (messageContent.includes('홈페이지')) {
        autoReply = '홈페이지는 <a href="main.do" target="_blank">여기</a>로 방문하실 수 있습니다.';
    } else if (messageContent.includes('상담사') || messageContent.includes('상담사 요청')) {
        autoReply = '상담사와 연결을 진행합니다.<br>잠시만 기다려주세요.';
        autoReplyEnabled = false; // 상담사 요청 시 자동응답 비활성화
    } else {
        autoReply = '죄송하지만, 제가 이해하지 못했습니다.<br>다시 한 번 말씀해 주실 수 있나요?<br>상담사 요청이 필요하시면 상담사 또는 상담사 요청 이라고 적어주세요.';
    }

    if (autoReply) {
        setTimeout(() => {
            var chatMessage = {
                sender: '챗봇',
                content: autoReply,
                type: 'CHAT'
            };

            stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
        }, 500); // 사용자의 메시지 처리 후 500ms 지연
    }
}

function onMessageReceived(payload) {
    var message = JSON.parse(payload.body);
    var messageElement = document.createElement('li');

    if (message.type === 'JOIN') {
        messageElement.classList.add('event-message');
        message.content = message.sender + ' joined!';
    } else if (message.type === 'LEAVE') {
        messageElement.classList.add('event-message');
        message.content = message.sender + ' left!';
    } else {
        var textElement = document.createElement('span');
        textElement.innerHTML = message.content;
        messageElement.appendChild(textElement);

        if (message.sender === username) {
            messageElement.classList.add('chat-message');
        } else {
            messageElement.classList.add('incoming-message');
        }
    }

    document.getElementById("messageArea").appendChild(messageElement);
    scrollToBottom(); // 항상 채팅창 맨 아래로 스크롤
}

function handleButtonClick(action) {
    var responseMessage = '';
    if (action === 'reserv') {
        responseMessage = '승차권 예약 페이지로 이동 <a href="ticket.do" target="_blank">이동하기</a><br>환불 안내 페이지로 이동 <a href="ticketManagement.do" target="_blank">이동하기</a>';
    } else if (action === 'lost') {
        responseMessage = '유실물 안내 페이지로 이동 <a href="lostList.do" target="_blank">이동하기</a>';
    } else if (action === 'FAQ') {
        responseMessage = '자주하는 질문 페이지로 이동 <a href="faqList.do" target="_blank">이동하기</a>';
    } else if (action === 'tour') {
        responseMessage = '관광열차 페이지로 이동 <a href="tourtrain.do" target="_blank">이동하기</a>';
    }

    if (responseMessage) {
        var chatMessage = {
            sender: '챗봇',
            content: responseMessage,
            type: 'CHAT'
        };

        stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
    }
}

function handleConsultationRequest() {
    autoReplyEnabled = false; // 상담사 연결 요청 시 자동응답 비활성화
    var chatMessage = {
        sender: '챗봇',
        content: '상담사와 연결을 진행합니다. 잠시만 기다려주세요.',
        type: 'CHAT'
    };
    stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
}

function handleEndConsultation() {
    autoReplyEnabled = true; // 상담 종료 시 자동응답 기능 재활성화
}

function handleKeyPress(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}

function scrollToBottom() {
    var chat = document.getElementById("chat");
    chat.scrollTop = chat.scrollHeight;
}

document.addEventListener('DOMContentLoaded', (event) => {
    var messageInput = document.getElementById("message");
    messageInput.addEventListener("keypress", handleKeyPress);
});

document.addEventListener('DOMContentLoaded', (event) => {
    var urlParams = new URLSearchParams(window.location.search);
    var userid = urlParams.get('userid');
    
    if (userid) {
        document.getElementById("name").value = userid; // ID를 name 필드에 자동 입력
        connect(); // 사용자 ID로 자동 연결
    } else {
        alert("로그인이 필요합니다. 로그인 후 이용 부탁드립니다.");
    }
});
