package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.TourVO;

@Mapper
@Repository("TourDAO")
public interface TourDAO {
	List<TourVO> tourList() throws DataAccessException;

	void tourDelete(String tournum);

	void tourReserv(TourVO tourVO);

	List<TourVO> cartList(String userid) throws Exception;
	
	List<TourVO> trainList(String userid) throws Exception;

    void delTourCart(int reservno);
    
    void delTrainCart(int reservno);

    void insertPaymentRecord(TourVO paymentRecord);    

	List<TourVO> tourTicket(int apply_num) throws Exception;

	void deltrainticket(int reservno) throws Exception;
	
	void deltourticket(int reservno) throws Exception;

	List<TourVO> mgmtTrain(int userid) throws Exception;
	
	List<TourVO> mgmtTour(int userid) throws Exception;
	
	List<TourVO> refundTrain(int apply_num) throws Exception;
	
	List<TourVO> refundTour(int apply_num) throws Exception;

	void refundUpTour(int apply_num) throws Exception;

	void refundUpTrain(int apply_num) throws Exception;

	List<TourVO> usageTrain(int userid) throws Exception;

	List<TourVO> usageTour(int userid) throws Exception;
	
    List<TourVO> trainSearch(@Param("userid") int userid, 
            @Param("startDate") java.util.Date startDate, 
            @Param("endDate") java.util.Date endDate) throws Exception;

    List<TourVO> tourSearch(@Param("userid") int userid, 
            @Param("startDate") java.util.Date startDate, 
            @Param("endDate") java.util.Date endDate) throws Exception;
}
