package com.project.crx.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.InfoDAO;

@Service("infoService")
public class InfoServiceImpl implements InfoService {

    @Autowired
    private InfoDAO infoDAO;

    // 승차권 조회
    @Override
    public Integer getRefundAmount(String applyNum) throws Exception {
        if (applyNum.length() == 6) {
            // applyNum이 6자리일 경우 paytrain 테이블에서 조회
            return infoDAO.getTotalCharge(Integer.parseInt(applyNum));
        } else if (applyNum.length() == 8) {
            // applyNum이 8자리일 경우 paytour 테이블에서 조회
            return infoDAO.getCoin(applyNum);
        }
        return null;
    }
}
