package com.project.crx.vo;

import java.io.File;
import java.sql.Date;

public class TourVO {
	private int memid;
	private String tourname;
	private String tourno;
	private String tourcount;
	private Date tourdate;
	private int no;
	private String title;
	private String ment;
	private String content;
	private String cost;
	private String noted;
	private File file1;
	private File file2;
	private File file3;
	
	public int getMemid() {
		return memid;
	}
	public void setMemid(int memid) {
		this.memid = memid;
	}
	public String getTourname() {
		return tourname;
	}
	public void setTourname(String tourname) {
		this.tourname = tourname;
	}
	public String getTourno() {
		return tourno;
	}
	public void setTourno(String tourno) {
		this.tourno = tourno;
	}
	public String getTourcount() {
		return tourcount;
	}
	public void setTourcount(String tourcount) {
		this.tourcount = tourcount;
	}
	public Date getTourdate() {
		return tourdate;
	}
	public void setTourdate(Date tourdate) {
		this.tourdate = tourdate;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMent() {
		return ment;
	}
	public void setMent(String ment) {
		this.ment = ment;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getNoted() {
		return noted;
	}
	public void setNoted(String noted) {
		this.noted = noted;
	}
	public File getFile1() {
		return file1;
	}
	public void setFile1(File file1) {
		this.file1 = file1;
	}
	public File getFile2() {
		return file2;
	}
	public void setFile2(File file2) {
		this.file2 = file2;
	}
	public File getFile3() {
		return file3;
	}
	public void setFile3(File file3) {
		this.file3 = file3;
	}
	
	
}
