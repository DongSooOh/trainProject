package com.project.crx.controller;

public class InfoController {

}
