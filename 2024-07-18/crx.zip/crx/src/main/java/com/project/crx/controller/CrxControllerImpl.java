package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CrxControllerImpl {

    @GetMapping("/main.do")
    public String main() {
        return "main"; 
    }
        
    @GetMapping("/noticeList.do")
    public String noticeList() {
        return "noticeList"; 
    }
    
    @GetMapping("/noticeWrite.do")
    public String noticeWrite() {
        return "noticeWrite"; 
    }
    
    @GetMapping("/noticeDetail.do")
    public String noticeDetail() {
        return "noticeDetail"; 
    }
    
    @GetMapping("/map.do")
    public String map() {
        return "map"; 
    }
    
    @GetMapping("/mapSearch.do")
    public String mapSearch() {
        return "mapSearch"; 
    }
    
    
}