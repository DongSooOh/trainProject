package com.project.crx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrxApplication.class, args);
	}

}
