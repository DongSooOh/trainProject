package com.project.crx.controller;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface CusController {

	/* 고객안내 */
	
	/* 공지사항 */
	
	// 공지사항 목록
	ModelAndView noticeList(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 공지사항 등록
	public ModelAndView noticeAdd(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception;
}
