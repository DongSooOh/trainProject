package com.project.crx.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.CusService;
import com.project.crx.vo.CusVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class CusControllerImpl implements CusController {
	
	// Service 연결
	@Autowired
	private CusService cusService;
	
	@Autowired
	private CusVO cusVO;
    
    /* 공지사항 */
    
    // 공지사항 목록
	@Override
    @GetMapping("/noticeList.do")
    public ModelAndView noticeList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("/noticeList");
		List<CusVO> noticeList = cusService.noticeList();
		mav.addObject("noticeList", noticeList);
		return mav;
    }
    
    // 공지사항 작성
    @GetMapping("/noticeAdd.do")
    public ModelAndView noticeAdd() {
        ModelAndView mav = new ModelAndView("noticeAdd");
    	return mav; 
    }
    
    // 공지사항 등록
    @Override
    @PostMapping("/noticeAdd.do")
    public ModelAndView noticeAdd(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
    	ModelAndView mav = new ModelAndView();
    	
    	try {
    		CusVO cusVO = new CusVO();
    		cusVO.setNotitle(request.getParameter("notitle"));
    		cusVO.setNocontent(request.getParameter("nocontent"));
    		cusVO.setNohit(0);
    		   	
    		LocalDate now = LocalDate.now();
    		Date nodate = Date.valueOf(now);
    		cusVO.setNodate(nodate);
    		
    		HttpSession session = request.getSession();
    		session.setAttribute("memid", member.getMemid());
    		
    		String memid = (String) request.getSession().getAttribute("memid");
            if (memid != null) {
                int memidStr = Integer.parseInt(memid);
                cusVO.setMember_memid(memidStr);
            }
    		System.out.println("memid: " + memid);
    		cusService.noticeAdd(cusVO);
    		
    		mav.addObject("message", "공지사항이 등록되었습니다.");
    		mav.setViewName("redirect:/noticeList.do");
    	} catch (Exception e) {
    		e.printStackTrace();
    		mav.addObject("message", "공지사항 등록에 실패했습니다.");
    		mav.setViewName("noticeAdd");
    	}
    	return mav;
    } 
    
    // 공지사항 상세보기
    @GetMapping("/noticeDetail.do")
    public String noticeDetail() {
        return "noticeDetail"; 
    }
    
    // 공지사항 수정
    @GetMapping("/noticeMod.do")
    public String noticeMod() {
        return "noticeMod"; 
    }
    
    @GetMapping("/noticeUpdate.do")
    public String noticeUpdate() {
        return "noticeUpdate"; 
    }
    
    // 공지사항 삭제
    @GetMapping("/noticeDelete.do")
    public String noticeDelete() {
        return "noticeList"; 
    }
    
    /* FAQ */
    
    // FAQ 목록
    @GetMapping("/faqList.do")
    public String faqList() {
        return "/faqList"; 
    }
    
    // FAQ 작성
    @GetMapping("/faqAdd.do")
    public String faqAdd() {
        return "/faqAdd"; 
    }
    
    // FAQ 상세보기
    @GetMapping("/faqDetail.do")
    public String faqDetail() {
        return "/faqDetail";
    }
    
    // FAQ 수정
    @GetMapping("/faqMod.do")
    public String faqMod() {
        return "/faqMod"; 
    }
    
    @GetMapping("/faqUpdate.do")
    public String faqUpdate() {
        return "faqUpdate"; 
    }
    
    // FAQ 삭제
    @GetMapping("/faqDelete.do")
    public String faqDelete() {
        return "/faqList"; 
    }
    
    /* 고객센터 */
    
    // 공지사항
    @GetMapping("/customerservice.do")
    public String customerservice() {
        return "customerservice"; 
    }
    
    /* 유실물 안내 */
    
    // 유실물 목록
    @GetMapping("/lostItemList.do")
    public String lostItemList() {
        return "/lostItemList"; 
    }
    
    // 유실물 작성
    @GetMapping("/lostItemAdd.do")
    public String lostItemAdd() {
        return "/lostItemAdd"; 
    }
    
    // 유실물 상세보기
    @GetMapping("/lostItemDetail.do")
    public String lostItemDetail() {
        return "/lostItemDetail";
    }
    
    /* 안내사항 */
    
    // 안내사항
    @GetMapping("/guideline.do")
    public String guideline() {
        return "guideline"; 
    }
    
    /* Q&A */
    
    // Q&A 목록
    @GetMapping("/qnaList.do")
    public String qnaList() {
        return "qnaList"; 
    }
    
    // Q&A 작성
    @GetMapping("/qnaAdd.do")
    public String qnaAdd() {
        return "qnaAdd"; 
    }
    
    // Q&A 상세보기
    @GetMapping("/qnaDetail.do")
    public String qnaDetail() {
        return "qnaDetail"; 
    }
    
    // Q&A 수정
    @GetMapping("/qnaMod.do")
    public String qnaMod() {
        return "qnaMod"; 
    }
    
    @GetMapping("/qnaUpdate.do")
    public String qnaUpdate() {
        return "qnaUpdate"; 
    }
    
    // Q&A 삭제
    @GetMapping("/qnaDelete.do")
    public String qnaDelete() {
        return "qnaList"; 
    }
    
    // Q&A 댓글 목록
    @GetMapping("/replyList.do")
    public String replyList() {
    	return "replyList";
    }
    
    // Q&A 댓글 상세보기
    @GetMapping("/replyDetail.do")
    public String replyDetail() {
    	return "replyDetail";
    }
}