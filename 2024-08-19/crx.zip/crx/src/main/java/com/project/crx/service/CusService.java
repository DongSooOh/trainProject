package com.project.crx.service;

import java.util.List;

import com.project.crx.vo.CusVO;

public interface CusService {
	
	List<CusVO> noticeList() throws Exception;

	public void noticeAdd(CusVO cusVO) throws Exception; 
}
