package com.project.crx;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import com.project.crx.ChatVO;

@Controller
public class ChatControllerImple {

    private final SimpMessagingTemplate messagingTemplate;

    public ChatControllerImple(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatVO sendMessage(ChatVO chatMessage) {
        return chatMessage;
    }

    @MessageMapping("/chat.addUser")
    @SendTo("/topic/public")
    public ChatVO addUser(ChatVO chatMessage) {
        chatMessage.setType(ChatVO.MessageType.JOIN);
        chatMessage.setContent(chatMessage.getSender() + " joined!");
        return chatMessage;
    }
}