package com.project.crx.service;

import java.util.List;

import com.project.crx.vo.CusVO;

public interface CusService {
	
	/* 고객안내 */
	
	/* 공지사항 */
	
	// 공지사항 목록
	List<CusVO> noticeList() throws Exception;

	// 공지사항 등록
	void noticeAdd(CusVO cusVO) throws Exception;
	
	// 공지사항 상세보기
	CusVO noticeDetail(int nono) throws Exception;
	
	// 공지사항 조회수 증가
	void hitChk(int nono) throws Exception;
	
	// 공지사항 수정
	void noticeUpdate(CusVO cusVO) throws Exception;
	
	// 공지사항 삭제
	void noticeDelete(int nono) throws Exception;
}
