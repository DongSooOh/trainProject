package com.project.crx.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.CrxService;
import com.project.crx.vo.CrxVO;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class CrxControllerImpl implements CrxController {

	@Autowired
	private CrxService crxService;

	@Override
	@GetMapping("/main.do")
	public ModelAndView main(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("main");
	}

	@GetMapping("/login.do")
	public String login() {
		return "login"; // login.jsp와 같은 뷰 이름을 반환
	}

   @Override
    @PostMapping("/login.do")
    public ModelAndView login(CrxVO crxVO, 
                              RedirectAttributes rAttr, 
                              HttpServletRequest request, 
                              HttpServletResponse response) throws Exception {
        ModelAndView mav = new ModelAndView();

        CrxVO loginUser = null;
        String loginType = request.getParameter("loginType");

        if (loginType == null || "user".equals(loginType)) {
            loginUser = crxService.login(crxVO);
        } else if ("member".equals(loginType)) {
            loginUser = crxService.login(crxVO);
        }

        if (loginUser != null) {
            // 로그인 성공
            HttpSession session = request.getSession();
            session.setAttribute("loginUser", loginUser);
            session.setAttribute("username", loginUser.getUsername());
            session.setAttribute("userid", loginUser.getUserid());
            session.setAttribute("level", loginUser.getLevel());
            session.setAttribute("divname", loginUser.getDivname());
            session.setAttribute("isLogOn", true);
            session.setMaxInactiveInterval(1800); // 30분 세션 유지

            mav.setViewName("redirect:/main.do");
        } else {
            rAttr.addFlashAttribute("result", "회원번호 또는 비밀번호가 일치하지 않습니다.");
            mav.setViewName("redirect:/login.do");
        }
        
        return mav;
    }

	@Override
	@GetMapping("/logout.do")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.invalidate(); // 세션 무효화

		// 모든 쿠키 삭제
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				cookie.setValue(null);
				cookie.setMaxAge(0);
				cookie.setPath("/"); // 쿠키 경로 설정
				response.addCookie(cookie);
			}
		}

		return new ModelAndView("redirect:/main.do"); // 로그인 페이지로 리다이렉트
	}

	@PostMapping("/updateUserInfo.do")
	public ModelAndView updateUserInfo(@ModelAttribute("crx") CrxVO crxVO, RedirectAttributes rAttr,
	                                   HttpServletRequest request, HttpServletResponse response) throws Exception {
	    HttpSession session = request.getSession();
	    Integer userIdInt = (Integer) session.getAttribute("userid");

	    if (userIdInt == null) {
	        return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
	    }

	    // 사용자 정보 가져오기
	    CrxVO currentUser = crxService.userInfo(userIdInt);

	    // level에 따라 수정할 테이블 결정
	    if ("user".equals(currentUser.getLevel())) {
	        // user 테이블에서 업데이트
	        crxVO.setUserid(userIdInt); // userId 설정
	        crxService.updateUserInfo(crxVO);
	    } else {
	        // member 테이블에서 업데이트
	        crxVO.setMemid(userIdInt); // memberId 설정

	        // member 테이블의 필드 설정
	        crxVO.setMemname(crxVO.getUsername());
	        crxVO.setMembirth(crxVO.getUserbirth());
	        crxVO.setMemtel(crxVO.getUsertel());
	        crxVO.setMemmail(crxVO.getUsermail());
	        crxVO.setMemadd(crxVO.getUseradd());

	        crxService.updateMemberInfo(crxVO);
	    }        

	    // 세션 갱신
	    session.setAttribute("crxVO", crxVO); 

	    rAttr.addFlashAttribute("updateSuccess", true);
	    return new ModelAndView("redirect:/mypage.do");
	}
	
	@Override
	@GetMapping("/confirm.do")
	public ModelAndView confirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("confirm");
	}

	@Override
	@GetMapping("/childConfirm.do")
	public ModelAndView childConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("childConfirm");
	}

	@Override
	@GetMapping("/findId.do")
	public ModelAndView findId(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("findId");
	}

	@Override
	@GetMapping("/findPwd.do")
	public ModelAndView findPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("findPwd");
	}

	@Override
	@GetMapping("/signup.do")
	public ModelAndView signup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("signup");
	}

	@Override
	@GetMapping("/childSignup.do")
	public ModelAndView childSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("childSignup");
	}

	@Override
	@GetMapping("/finishSignup.do")
	public ModelAndView finishSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("finishSignup");
	}

	@Override
	@GetMapping("/signupTerms.do")
	public ModelAndView signupTerms(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("signupTerms");
	}

	@Override
	@GetMapping("/finishFindId.do")
	public ModelAndView finishFindId(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("finishFindId");
	}

	@Override
	@GetMapping("/finishFindPwd.do")
	public ModelAndView finishFindPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("finishFindPwd");
	}

	@Override
	@GetMapping("/selectSignup.do")
	public ModelAndView selectSignup(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("selectSignup");
	}

	@Override
	@GetMapping("/subway.do")
	public ModelAndView subway(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("subway");
	}

    @GetMapping("/mypage.do")
    public ModelAndView mypage(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        Integer userIdInt = (Integer) session.getAttribute("userid");
        String usermail = (String) session.getAttribute("usermail");

        CrxVO crxVO;
        if (userIdInt != null) {
            crxVO = crxService.userInfo(userIdInt);
        } else if (usermail != null) {
            crxVO = crxService.userInfoEmail(usermail);
        } else {
            return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
        }

        session.setAttribute("crxVO", crxVO);

        // 부서별로 데이터를 가져옴
        List<CrxVO> masterList = crxService.memList("통합관리");
        List<CrxVO> reservList = crxService.memList("예매관리");
        List<CrxVO> customerList = crxService.memList("고객안내");
        List<CrxVO> usageList = crxService.memList("이용안내");
        List<CrxVO> tourList = crxService.memList("여행상품");

        // 전체 데이터를 담을 통합 리스트 생성
        List<CrxVO> totalList = new ArrayList<>();

        // 부서별 리스트를 통합 리스트에 추가
        totalList.addAll(masterList);
        totalList.addAll(reservList);
        totalList.addAll(customerList);
        totalList.addAll(usageList);
        totalList.addAll(tourList);
        
        // totalList를 memid 기준으로 오름차순 정렬
        totalList.sort((o1, o2) -> Integer.compare(o1.getMemid(), o2.getMemid()));
        
        ModelAndView mav = new ModelAndView("mypage");
        mav.addObject("crxVO", crxVO);
        mav.addObject("masterList", masterList);
        mav.addObject("reservList", reservList);
        mav.addObject("customerList", customerList);
        mav.addObject("usageList", usageList);
        mav.addObject("tourList", tourList);
        mav.addObject("totalList", totalList);
        return mav;
    }


	@PostMapping("/updateUserPwd.do")
	public ModelAndView updateUserPwd(HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes rAttr) throws Exception {
		HttpSession session = request.getSession();
		Integer userIdInt = (Integer) session.getAttribute("userid");
		String usermail = (String) session.getAttribute("usermail");

		if (userIdInt == null && usermail == null) {
			return new ModelAndView("redirect:/login.do"); // 로그인 페이지로 리다이렉트
		}

		String currentPwd = request.getParameter("currentpwd");
		String newPwd = request.getParameter("userpwd");

		CrxVO currentUser;
		if (userIdInt != null) {
			// 일반 사용자
			currentUser = crxService.userInfo(userIdInt);
			if (!currentUser.getUserpwd().equals(currentPwd)) {
				rAttr.addFlashAttribute("result", "현재 비밀번호가 일치하지 않습니다.");
				return new ModelAndView("redirect:/mypage.do");
			}
			// 새 비밀번호 설정
			currentUser.setUserpwd(newPwd);
			crxService.updatePwdId(currentUser);
		} else if (usermail != null) {
			// 카카오 사용자
			currentUser = crxService.userInfoEmail(usermail);
			if (!currentUser.getUserpwd().equals(currentPwd)) {
				rAttr.addFlashAttribute("result", "현재 비밀번호가 일치하지 않습니다.");
				return new ModelAndView("redirect:/mypage.do");
			}
			// 새 비밀번호 설정
			currentUser.setUserpwd(newPwd);
			crxService.updatePwdMail(currentUser);
		}

		rAttr.addFlashAttribute("result", "비밀번호가 성공적으로 변경되었습니다.");
		return new ModelAndView("redirect:/mypage.do");
	}

	@GetMapping("/zipcode.do")
	public String zipcode() {
		return "zipcode";
	}

	@GetMapping("/chatbot.do")
	public String chatbot() {
		return "chatbot";
	}
	
	@PostMapping("/gradeUp")
	public ModelAndView updateGrade(@RequestParam("userid") int userid, @RequestParam("level") String level) {
	    crxService.updateGrade(userid, level);
	    return new ModelAndView("redirect:/mypage.do?tab=leveling");
	}
}