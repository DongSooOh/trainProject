function payMent() {
    alert('결제 페이지로 이동합니다.');
    window.location.href = 'payment.do'; // 결제 페이지 URL로 변경
}

function Checkboxes(source, targetClass) {
    var checkboxes = document.getElementsByClassName(targetClass);
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].disabled = source.checked;
    }
}

function validateForm() {
    // 관광상품 체크박스 중 하나라도 선택되었는지 확인
    var checkboxes = document.getElementsByName("selectTour[]");
    var isChecked = false;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            isChecked = true;
            break;
        }
    }

    // 선택된 항목이 없으면 alert 띄우기
    if (!isChecked) {
        alert("삭제할 항목을 선택해 주세요.");
        return false; // 폼 제출을 막음
    }

    // 선택된 항목이 있으면 삭제 확인 메시지 띄우기
    return confirm("선택한 항목을 삭제하시겠습니까?");
}